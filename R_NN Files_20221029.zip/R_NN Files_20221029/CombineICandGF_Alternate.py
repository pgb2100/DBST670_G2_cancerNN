# Import required packages
import pandas as pd
import numpy as np

# Determine filenames
ICFile = 'PANCANCER_IC_Wed.csv'
MPFile = 'Hotspot_Mutations.csv'

# Read in the data
dataframeIC = pd.read_csv(ICFile)
dataframeMP = pd.read_csv(MPFile)

# Remove unnecessary columns
dataframeIC = dataframeIC.drop(['Drug Name', 'TCGA Classification', 'Tissue', 'Tissue Sub-type', 'AUC', 'Max Conc',
                                'RMSE', 'Z score', 'Dataset Version'], axis=1)

# Get the column headers from each dataframe
ICHeaders = dataframeIC.columns.values.tolist()
MPHeaders = dataframeMP.columns.values.tolist()
allHeaders = ICHeaders + MPHeaders

# Convert dataframes to lists for processing
dataframeICList = dataframeIC.values.tolist()
dataframeMPList = dataframeMP.values.tolist()
comboList = []

# Determine which indicies hold negative IC50 values
indexToDrop = []
for x in range(len(dataframeICList)):
    if dataframeICList[x][3] < 0:
        indexToDrop.append(x)

# Drop negative IC50 values from dataset
for x in range(len(indexToDrop)):
    dataframeICList.pop(x)

# Pull all IC values into separate list
ICList = []
for x in range(len(dataframeICList)):
    ICList.append(dataframeICList[x][3])

# Convert IC list to numpy array for processing
ICArray = np.array(ICList)

# Determine the lowest 25% and 75% classes of IC values
class1 = np.percentile(ICArray, 25)
class2 = np.percentile(ICArray, 75)

# Iterate through IC list and convert IC values into 3 factor groups based on percentile
for x in range(len(dataframeICList)):
    if dataframeICList[x][3] <= class1:
        dataframeICList[x][3] = 1
    elif class1 < dataframeICList[x][3] <= class2:
        dataframeICList[x][3] = 2
    else:
        dataframeICList[x][3] = 3

# Loop through and combine rows with matching Cell Line Name value
for x in range(len(dataframeICList)):
    for y in range(len(dataframeMPList)):
        if dataframeICList[x][1] == dataframeMPList[y][0]:
            comboList.append(dataframeICList[x]+dataframeMPList[y])

# Convert list to dataframe
comboFrame = pd.DataFrame(comboList, columns=allHeaders)
print(comboFrame.shape)

# View total size of the dataframe
comboFrame = comboFrame.drop(['Cell Line Name', 'CLN'], axis=1)

# Remove columns containing only zeros
comboFrame = comboFrame.loc[:, (comboFrame != 0).any(axis=0)]
print(comboFrame.shape)

# Export final combined data as csv file
comboFrame.to_csv('ComboData.csv', index=False)

